export const AI_USER = 'ai_user';
export const NAV_USER = 'nav_user';
